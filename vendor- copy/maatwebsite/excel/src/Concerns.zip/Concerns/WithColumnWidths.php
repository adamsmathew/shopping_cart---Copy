<?php

namespace Maatwebsite\Excel\Concerns;

interface WithColumnWidths
{
    public function columnWidths(): array;
}
